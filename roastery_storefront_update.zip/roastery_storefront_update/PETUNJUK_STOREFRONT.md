# Pembaruan Beranda, Tentang, dan Footer (Roastery Supply)

Salin isi folder ini ke root proyek Laravel (timpa file yang sama), lalu jalankan:

    php artisan migrate          # WAJIB: memperbarui teks Tentang lama (lihat di bawah)
    php artisan config:clear     # pengaturan baru di config/cms.php
    php artisan view:clear
    npm run build                # atau npm run dev

`resources/css/app.css` di sini memuat SEMUA CSS (login/daftar, admin, dan beranda/Tentang). Cukup pakai file ini.

## Yang berubah
1. **Hero beranda**: foto latar tidak lagi di-blur dan ditutup overlay 85-90%. Gelap hanya di belakang teks lalu memudar ke kanan,
   sehingga foto terlihat. Di HP, gelap di bagian atas (teks) dan lebih terang di bawah.
2. **Strip 4 kartu** diganti daftar layanan bernomor dengan teks baru. Daftar ada di bagian atas `customer/home.blade.php` (`$services`).
3. **Halaman Tentang** disusun ulang: hero, profil usaha, nilai kerja (6 butir), merek & rekanan (dari Admin > Partner), ajakan hubungi.
4. **Footer**: baris "Chat via WhatsApp" dan jam operasional dihapus (jam operasional tetap ada di halaman Kontak).

## Admin > Pengaturan > Halaman Tentang (baru bisa diatur)
- Label Halaman, Judul Utama, Paragraf Pembuka, Profil Usaha (pisahkan paragraf dengan baris kosong)
- **Foto Utama Halaman Tentang** (sisi kanan hero) dan **Foto Profil Usaha**: opsional. Tanpa foto, halaman tetap rapi (pola biji kopi / teks saja).
- **Admin > Pengaturan > Tampilan > Background Beranda**: foto hero beranda.

## Soal migrasi
Seeder lama menyimpan satu kalimat Tentang ke database, sehingga teks baru tidak akan tampil. Migrasi
`2026_10_13_000001_refresh_about_page_copy` menghapus baris itu HANYA bila isinya masih persis kalimat lama.
Bila Anda sudah menulis profil sendiri, isinya tidak disentuh.

## Sebelum tayang, periksa isi teks
Teks bawaan sengaja hanya memuat klaim yang sudah ada di situs lama (garansi resmi, sparepart, pengiriman diasuransikan,
konsultasi, instalasi dan pelatihan). Tambahkan tahun berdiri, jumlah cabang, penghargaan, atau sertifikasi HANYA bila datanya benar.
Daftar nilai kerja ada di `customer/about.blade.php` (`$values`).

## Saran foto
- Hero beranda: 1920 x 1000 px, JPG/WEBP, di bawah 400 KB. Subjek utama sebaiknya di sisi kanan; sisi kiri dipakai teks.
- Foto Tentang: 1600 x 1000 px (utama) dan 1200 x 900 px (profil), di bawah 350 KB.
